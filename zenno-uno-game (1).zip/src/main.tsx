/**
 * ZENNO UNO
 * 
 * Copyright (c) 2026 Alexander Laggui. All Rights Reserved.
 * 
 * This source code is the intellectual property of Alexander Laggui.
 * Unauthorized copying, modification, or redistribution of this file,
 * via any medium, is strictly prohibited.
 */
import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
